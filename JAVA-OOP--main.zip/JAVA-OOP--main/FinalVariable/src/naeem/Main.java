package naeem;

public class Main {
   final int x = 15;

    public static void main(String[] args) {

        Main main = new Main();
        main.x = 20;
        System.out.println(main.x);

    }
}
