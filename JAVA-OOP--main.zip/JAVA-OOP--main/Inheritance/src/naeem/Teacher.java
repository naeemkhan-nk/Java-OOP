package naeem;

public class Teacher extends Person{
    String departmant;
    void disply2(){
        System.out.println("Name : "+name);
        System.out.println("Id : "+id);
        System.out.println("Departmant : "+departmant);
    }
}
