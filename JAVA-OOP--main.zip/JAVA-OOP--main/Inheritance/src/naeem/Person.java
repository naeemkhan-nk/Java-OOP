package naeem;

public class Person {
    String name;
    int id;

    void disply1(){
        System.out.println("Name : "+name);
        System.out.println("Id : "+id);
    }
}
