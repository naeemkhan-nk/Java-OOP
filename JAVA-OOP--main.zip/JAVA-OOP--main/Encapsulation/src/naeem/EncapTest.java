package naeem;

public class EncapTest {
    /*int id;
    String name;

    void disply(){
        System.out.println("Name : "+name);
        System.out.println("ID : "+id);*/

    private int age;
    private String name;

      public void setName(String name){
          this.name = name;
      }
      public String getName(){
          return name;
      }

      public void setAge(int age){
          this.age = age;
      }
      public int getAge(){
          return age;
      }

}
