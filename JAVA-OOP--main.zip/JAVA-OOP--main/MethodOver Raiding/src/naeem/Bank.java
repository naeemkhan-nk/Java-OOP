package naeem;

public class Bank {
    float reteOfInterest()
    {
        return 9;
    }
}
