package naeem;

public class UCBL extends Bank{
    @Override
    float reteOfInterest() {
        return 10;
    }
}
