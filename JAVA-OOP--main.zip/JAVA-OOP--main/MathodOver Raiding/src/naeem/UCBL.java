package naeem;

public class UCBL extends Bank {
    @Override
    double rateOfInterst() {
        return 7.5;
    }
}
