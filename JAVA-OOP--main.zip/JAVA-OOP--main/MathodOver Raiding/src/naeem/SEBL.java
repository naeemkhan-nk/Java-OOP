package naeem;

public class SEBL extends Bank{
    @Override
    double rateOfInterst() {
        return 8;
    }
}
