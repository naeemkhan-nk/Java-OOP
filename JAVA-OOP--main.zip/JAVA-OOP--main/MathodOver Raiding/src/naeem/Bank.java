package naeem;

public class Bank {
    double rateOfInterst(){
        return 9;
    }
}
