package naeem;

public class EBL extends Bank{
    @Override
    double rateOfInterst() {
        return 6.7;
    }
}
