package naeem;

public class Main {

    public static void main(String[] args) {

        Student student1 = new Student();
        student1.setinput("Naeem Khan","Male",17520);
        student1.displayINformation();
        System.out.println();

        Student student2 = new Student();
        student2.setinput("Khan","Male",170);
        student2.displayINformation();
        System.out.println();

        Student student3 = new Student();
        student3.setinput("Naeem","Male",520);
        student3.displayINformation();



    }
}
