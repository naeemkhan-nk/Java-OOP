package naeem;

public class Main {

    public static void main(String[] args) {

        Static s1 = new Static("naeem",2012020105);
        Static s2 = new Static("hira",2012020106);

        s1.disply();
        System.out.println();
        s2.disply();
    }
}
