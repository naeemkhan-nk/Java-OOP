package naeem;

public class Main {

    public static void main(String[] args) {

        for(int i=1; i<=50; i++){
            if(i == 10){
                continue;
            }
            System.out.println(i);
        }

    }
}
