package naeem;

public class Main {

    public static void main(String[] args) {

        Static.display();
    }
}
