package naeem;

public class Student {

    String name, university, department, section;
    int id, batch;



    void display() {
        System.out.println("Name : "+name);
        System.out.println("Student ID : "+id);
        System.out.println("Student Section : "+section);
        System.out.println("Student Batch : "+batch);
        System.out.println("University Name : "+university);
        System.out.println("Department Name : "+department);
    }
}


