package naeem;

public class Main {

    public static void main(String[] args) {

        Student student1 = new Student();
        student1.name = "Naeem Khan";
        student1.id = 2012020105;
        student1.section = "C";
        student1.batch = 53;
        student1.university = "Leading University,Sylhet";
        student1.department = "Computer Scince and Engineering";
        student1.display();





    }
}
